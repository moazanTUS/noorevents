"use client"

import { useState, useEffect, useRef, useCallback } from "react"
import { MapPin } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import Link from "next/link"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"

// Update the Google Maps API key constant to make it more obvious
// This is where you'll put your Google Maps API key
const GOOGLE_MAPS_API_KEY = "YOUR_GOOGLE_MAPS_API_KEY_HERE" // <-- Replace this with your actual API key

export function EventMap({ events, activeEvent, setActiveEvent }) {
  const mapRef = useRef(null)
  const [map, setMap] = useState(null)
  const [markers, setMarkers] = useState([])
  const [isLoaded, setIsLoaded] = useState(false)
  const [isLoadingScript, setIsLoadingScript] = useState(false)
  const [mapError, setMapError] = useState(null)

  // Load Google Maps script
  const loadGoogleMapsScript = useCallback(() => {
    if (typeof window === "undefined" || isLoadingScript) return

    // Check if Google Maps is already loaded
    if (window.google && window.google.maps) {
      console.log("Google Maps already loaded")
      setIsLoaded(true)
      return
    }

    // Check if script is already in the document
    const existingScript = document.querySelector('script[src*="maps.googleapis.com/maps/api/js"]')
    if (existingScript) {
      console.log("Google Maps script tag already exists")
      setIsLoaded(true)
      return
    }

    if (!GOOGLE_MAPS_API_KEY || GOOGLE_MAPS_API_KEY === "YOUR_GOOGLE_MAPS_API_KEY_HERE") {
      console.log("Using simulated map - replace with your Google Maps API key")
      setIsLoaded(true)
      return
    }

    setIsLoadingScript(true)

    const script = document.createElement("script")
    script.id = "google-maps-script"
    script.src = `https://maps.googleapis.com/maps/api/js?key=${GOOGLE_MAPS_API_KEY}&libraries=places`
    script.async = true
    script.defer = true

    script.onload = () => {
      setIsLoaded(true)
      setIsLoadingScript(false)
    }

    script.onerror = () => {
      setMapError("Failed to load Google Maps. Using fallback map.")
      setIsLoaded(true)
      setIsLoadingScript(false)
    }

    document.head.appendChild(script)

    return () => {
      // Only remove the script if we added it
      const scriptToRemove = document.getElementById("google-maps-script")
      if (scriptToRemove && scriptToRemove.parentNode) {
        scriptToRemove.parentNode.removeChild(scriptToRemove)
      }
    }
  }, [isLoadingScript])

  // Initialize map on component mount
  useEffect(() => {
    loadGoogleMapsScript()
  }, [loadGoogleMapsScript])

  // Initialize the map once script is loaded
  useEffect(() => {
    if (!isLoaded || !mapRef.current || map) return

    try {
      if (window.google && window.google.maps) {
        // Real Google Maps initialization
        const mapOptions = {
          center: { lat: 53.1424, lng: -7.6921 }, // Center of Ireland
          zoom: 7,
          mapTypeControl: false,
          streetViewControl: false,
          fullscreenControl: false,
          styles: [
            {
              featureType: "all",
              elementType: "labels.text.fill",
              stylers: [{ color: "#7c93a3" }, { lightness: -10 }],
            },
            {
              featureType: "administrative.country",
              elementType: "geometry",
              stylers: [{ visibility: "on" }],
            },
            {
              featureType: "administrative.country",
              elementType: "geometry.stroke",
              stylers: [{ color: "#a0a4a5" }],
            },
            {
              featureType: "administrative.province",
              elementType: "geometry.stroke",
              stylers: [{ color: "#62838e" }],
            },
            {
              featureType: "landscape",
              elementType: "geometry.fill",
              stylers: [{ color: "#dde3e3" }],
            },
            {
              featureType: "landscape.man_made",
              elementType: "geometry.stroke",
              stylers: [{ color: "#3f4a51" }, { weight: "0.30" }],
            },
            {
              featureType: "poi",
              elementType: "all",
              stylers: [{ visibility: "simplified" }],
            },
            {
              featureType: "poi.attraction",
              elementType: "all",
              stylers: [{ visibility: "on" }],
            },
            {
              featureType: "poi.business",
              elementType: "all",
              stylers: [{ visibility: "off" }],
            },
            {
              featureType: "poi.government",
              elementType: "all",
              stylers: [{ visibility: "off" }],
            },
            {
              featureType: "poi.park",
              elementType: "all",
              stylers: [{ visibility: "on" }],
            },
            {
              featureType: "poi.place_of_worship",
              elementType: "all",
              stylers: [{ visibility: "off" }],
            },
            {
              featureType: "poi.school",
              elementType: "all",
              stylers: [{ visibility: "off" }],
            },
            {
              featureType: "poi.sports_complex",
              elementType: "all",
              stylers: [{ visibility: "off" }],
            },
            {
              featureType: "road",
              elementType: "all",
              stylers: [{ saturation: -100 }, { visibility: "simplified" }],
            },
            {
              featureType: "road.highway",
              elementType: "all",
              stylers: [{ visibility: "on" }],
            },
            {
              featureType: "road.highway",
              elementType: "geometry",
              stylers: [{ color: "#e4e4e4" }],
            },
            {
              featureType: "road.highway",
              elementType: "labels.text",
              stylers: [{ visibility: "on" }],
            },
            {
              featureType: "transit",
              elementType: "labels.text",
              stylers: [{ visibility: "on" }],
            },
            {
              featureType: "transit.line",
              elementType: "geometry",
              stylers: [{ visibility: "on" }, { lightness: 700 }],
            },
            {
              featureType: "water",
              elementType: "all",
              stylers: [{ color: "#a3ccff" }],
            },
          ],
        }

        const newMap = new window.google.maps.Map(mapRef.current, mapOptions)
        setMap(newMap)

        // Add zoom controls
        const zoomInButton = document.getElementById("zoom-in")
        const zoomOutButton = document.getElementById("zoom-out")

        if (zoomInButton) {
          zoomInButton.addEventListener("click", () => {
            newMap.setZoom(newMap.getZoom() + 1)
          })
        }

        if (zoomOutButton) {
          zoomOutButton.addEventListener("click", () => {
            newMap.setZoom(newMap.getZoom() - 1)
          })
        }
      } else {
        // Fallback to simulated map
        console.log("Google Maps not available, using simulated map")
        setMap({
          setCenter: (coords) => console.log("Map center set to:", coords),
          setZoom: (zoom) => console.log("Map zoom set to:", zoom),
          markers: [],
        })
      }
    } catch (error) {
      console.error("Error initializing map:", error)
      setMapError("Error initializing map. Using fallback.")

      // Fallback to simulated map
      setMap({
        setCenter: (coords) => console.log("Map center set to:", coords),
        setZoom: (zoom) => console.log("Map zoom set to:", zoom),
        markers: [],
      })
    }
  }, [isLoaded, map])

  // Update markers when events or map changes
  useEffect(() => {
    if (!map || !events.length) return

    // Clear existing markers
    markers.forEach((marker) => {
      if (marker.setMap) {
        marker.setMap(null)
      }
    })

    // Create new markers
    const newMarkers = events.map((event) => {
      if (window.google && window.google.maps) {
        // Real Google Maps marker
        const marker = new window.google.maps.Marker({
          position: event.coordinates, // Use the coordinates object directly
          map: map,
          title: event.title,
          icon: {
            path: window.google.maps.SymbolPath.CIRCLE,
            fillColor: "#000",
            fillOpacity: 1,
            strokeWeight: 0,
            scale: 8,
          },
          zIndex: activeEvent === event.id ? 999 : 1,
        })

        // Add click event to marker
        marker.addListener("click", () => {
          setActiveEvent(activeEvent === event.id ? null : event.id)
        })

        return marker
      }

      // Simulated marker
      return {
        id: event.id,
        position: event.coordinates,
      }
    })

    setMarkers(newMarkers)
  }, [map, events, activeEvent, setActiveEvent])

  // If using real Google Maps, render the map container
  if (window.google && window.google.maps && map) {
    return (
      <div className="relative h-[400px] w-full">
        <div ref={mapRef} className="h-full w-full" />

        {/* Map controls */}
        <div className="absolute bottom-4 right-4 flex flex-col gap-2">
          <Button
            id="zoom-in"
            variant="outline"
            size="icon"
            className="bg-background/80 backdrop-blur-sm h-8 w-8 hover:bg-background transition-colors"
          >
            <span>+</span>
          </Button>
          <Button
            id="zoom-out"
            variant="outline"
            size="icon"
            className="bg-background/80 backdrop-blur-sm h-8 w-8 hover:bg-background transition-colors"
          >
            <span>-</span>
          </Button>
        </div>

        {/* Map attribution */}
        <div className="absolute bottom-1 right-1 text-[10px] text-black/70">
          Map data © {new Date().getFullYear()} Google
        </div>
      </div>
    )
  }

  // Fallback simulated map
  return (
    <div className="relative h-[400px] w-full bg-[#e5e3df] overflow-hidden">
      {mapError && (
        <div className="absolute top-2 left-2 right-2 bg-destructive/90 text-white text-sm p-2 rounded-md z-10">
          {mapError}
        </div>
      )}

      {/* Simulated Google Maps with Ireland map background */}
      <div className="absolute inset-0 overflow-hidden">
        <img
          src="/placeholder.svg?height=400&width=800&text=Map+of+Ireland"
          alt="Map of Ireland"
          className="h-full w-full object-cover"
        />
      </div>

      {/* Event location pins */}
      {events.map((event) => {
        // Calculate positions based on real coordinates but scaled to our container
        const left = ((event.coordinates.lng + 10) / 5) * 100
        const top = (55 - event.coordinates.lat) * 10
        const isActive = activeEvent === event.id

        return (
          <TooltipProvider key={event.id}>
            <Tooltip open={isActive}>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className={cn("absolute text-primary hover:text-primary map-pin", isActive && "active")}
                  style={{
                    left: `${Math.min(Math.max(left, 5), 95)}%`,
                    top: `${Math.min(Math.max(top, 5), 95)}%`,
                  }}
                  onClick={() => setActiveEvent(isActive ? null : event.id)}
                  onMouseEnter={() => setActiveEvent(event.id)}
                  onMouseLeave={() => setActiveEvent(null)}
                >
                  <MapPin className={cn("h-6 w-6", isActive ? "fill-black/50" : "fill-black/20")} />
                </Button>
              </TooltipTrigger>
              <TooltipContent side="top" className="p-0 overflow-hidden border-none shadow-lg animate-fade-in">
                <div className="w-64">
                  <div className="bg-black p-3 text-white">
                    <p className="font-medium">{event.title}</p>
                    <div className="flex items-center gap-1 text-xs mt-1">
                      <MapPin className="h-3 w-3" />
                      <span>{event.location}</span>
                    </div>
                  </div>
                  <div className="p-3 bg-card">
                    <p className="text-xs text-muted-foreground mb-2">{event.description}</p>
                    <div className="flex items-center justify-between">
                      <Badge variant="outline" className="text-xs">
                        {event.date}
                      </Badge>
                      <Link href={`/events/${event.id}`} className="text-xs text-black hover:underline">
                        View details
                      </Link>
                    </div>
                  </div>
                </div>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        )
      })}

      {/* Map controls */}
      <div className="absolute bottom-4 right-4 flex flex-col gap-2">
        <Button
          variant="outline"
          size="icon"
          className="bg-background/80 backdrop-blur-sm h-8 w-8 hover:bg-background transition-colors"
        >
          <span>+</span>
        </Button>
        <Button
          variant="outline"
          size="icon"
          className="bg-background/80 backdrop-blur-sm h-8 w-8 hover:bg-background transition-colors"
        >
          <span>-</span>
        </Button>
      </div>

      {/* Map attribution */}
      <div className="absolute bottom-1 right-1 text-[10px] text-black/70">Map data © {new Date().getFullYear()}</div>
    </div>
  )
}

