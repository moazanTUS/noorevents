"use client"

// Add the image to the EventCard component
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CalendarDays, Clock, MapPin, Users } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { cn } from "@/lib/utils"

function EventCard({ event, isActive, onMouseEnter, onMouseLeave }) {
  return (
    <Card
      className={cn("border-none shadow-md event-card", isActive && "ring-2 ring-primary/50")}
      onMouseEnter={onMouseEnter}
      onMouseLeave={onMouseLeave}
    >
      <CardHeader className="p-0">
        <div className="aspect-video w-full overflow-hidden rounded-t-lg">
          <img
            src={event.image || "/placeholder.svg?height=200&width=400"}
            alt={event.title}
            className="h-full w-full object-cover"
          />
        </div>
        <div className="p-6">
          <div className="flex justify-between items-start">
            <div>
              <CardTitle className="text-xl">{event.title}</CardTitle>
              <CardDescription className="mt-1">{event.description}</CardDescription>
            </div>
            <Badge className="bg-secondary hover:bg-secondary/90">{event.eventType || "Event"}</Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent className="px-6 pb-2">
        <div className="grid gap-3">
          <div className="flex items-center gap-2">
            <CalendarDays className="h-4 w-4 text-primary" />
            <span className="text-sm">{event.date}</span>
          </div>
          <div className="flex items-center gap-2">
            <Clock className="h-4 w-4 text-primary" />
            <span className="text-sm">{event.time}</span>
          </div>
          <div className="flex items-center gap-2">
            <MapPin className="h-4 w-4 text-primary" />
            <span className="text-sm">{event.location}</span>
          </div>
          <div className="flex items-center gap-2">
            <Users className="h-4 w-4 text-primary" />
            <span className="text-sm">{event.attendees} attendees</span>
          </div>
        </div>
      </CardContent>
      <CardFooter className="px-6 pb-6 pt-2">
        <Button asChild className="w-full bg-black text-white hover:bg-black/90 transition-opacity">
          <Link href={`/events/${event.id}`}>View Details</Link>
        </Button>
      </CardFooter>
    </Card>
  )
}

export default EventCard

