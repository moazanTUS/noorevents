"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { CalendarDays, Clock, Loader2, MapPin, Plus, Search, Users, X } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { EventCalendar } from "@/components/event-calendar"
import { Input } from "@/components/ui/input"
import { EventMap } from "@/components/event-map"
import { CreateEventModal } from "@/components/create-event-modal"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"

export default function Dashboard() {
  const [searchQuery, setSearchQuery] = useState("")
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [activeEvent, setActiveEvent] = useState(null)

  // Simulate loading state
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  // Filter events based on search query (name only)
  const filteredEvents = upcomingEvents.filter((event) => {
    const query = searchQuery.toLowerCase()
    return event.title.toLowerCase().includes(query)
  })

  return (
    <div className="flex min-h-screen w-full flex-col bg-gradient-to-b from-background to-muted/30">
      <header className="sticky top-0 z-10 flex h-16 items-center gap-4 border-b bg-background/80 backdrop-blur-md px-4 md:px-6">
        <div className="flex flex-1 items-center gap-2">
          <h1 className="text-xl font-bold text-black">NoorEvents</h1>
        </div>
        <div className="flex items-center gap-4">
          <Button
            onClick={() => setIsCreateModalOpen(true)}
            className="bg-black text-white hover:bg-black/90 transition-opacity"
          >
            <Plus className="mr-2 h-4 w-4" />
            Create Event
          </Button>
        </div>
      </header>
      <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8 animate-fade-in">
        <div className="space-y-4">
          <div className="relative search-bar">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search events by name..."
                className="pl-9 pr-4 py-2 transition-all duration-300 focus:ring-2 focus:ring-primary/20"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              {searchQuery && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute right-2 top-2 h-6 w-6 hover:bg-muted transition-colors"
                  onClick={() => setSearchQuery("")}
                >
                  <X className="h-4 w-4" />
                </Button>
              )}
            </div>
          </div>
          <Card className="overflow-hidden border-none shadow-lg">
            <CardHeader className="bg-gradient-to-r from-primary/10 to-secondary/10">
              <CardTitle>Event Locations in Ireland</CardTitle>
              <CardDescription>Interactive map of all event venues</CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              {isLoading ? (
                <div className="flex items-center justify-center h-[400px] bg-muted/30">
                  <div className="flex flex-col items-center gap-2">
                    <Loader2 className="h-8 w-8 text-primary animate-spin" />
                    <p className="text-sm text-muted-foreground">Loading map...</p>
                  </div>
                </div>
              ) : (
                <EventMap events={filteredEvents} activeEvent={activeEvent} setActiveEvent={setActiveEvent} />
              )}
            </CardContent>
          </Card>
        </div>
        <div className="grid gap-4 md:grid-cols-1">
          <Card className="border-none shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 bg-gradient-to-r from-primary/10 to-secondary/10">
              <CardTitle className="text-sm font-medium">Total Events</CardTitle>
              <CalendarDays className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent className="pt-4">
              <div className="text-2xl font-bold">{filteredEvents.length}</div>
              <p className="text-xs text-muted-foreground">
                {searchQuery ? `Showing ${filteredEvents.length} of ${upcomingEvents.length} events` : "Across Ireland"}
              </p>
            </CardContent>
          </Card>
        </div>
        <Tabs defaultValue="upcoming" className="space-y-4">
          <TabsList className="bg-muted/50 p-1">
            <TabsTrigger
              value="upcoming"
              className="data-[state=active]:bg-background data-[state=active]:text-foreground transition-all"
            >
              Upcoming Events
            </TabsTrigger>
            <TabsTrigger
              value="calendar"
              className="data-[state=active]:bg-background data-[state=active]:text-foreground transition-all"
            >
              Calendar
            </TabsTrigger>
          </TabsList>
          <TabsContent value="upcoming" className="space-y-4 animate-slide-up">
            {isLoading ? (
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {[1, 2, 3].map((i) => (
                  <Card key={i} className="border-none shadow-md opacity-50">
                    <CardHeader className="relative p-6 animate-pulse bg-muted">
                      <div className="h-6 w-2/3 bg-muted-foreground/20 rounded-md"></div>
                      <div className="h-4 w-full bg-muted-foreground/20 rounded-md mt-2"></div>
                    </CardHeader>
                    <CardContent className="p-6">
                      <div className="space-y-3">
                        <div className="h-4 w-full bg-muted-foreground/20 rounded-md"></div>
                        <div className="h-4 w-full bg-muted-foreground/20 rounded-md"></div>
                        <div className="h-4 w-2/3 bg-muted-foreground/20 rounded-md"></div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : filteredEvents.length > 0 ? (
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {filteredEvents.map((event) => (
                  <EventCard
                    key={event.id}
                    event={event}
                    isActive={activeEvent === event.id}
                    onMouseEnter={() => setActiveEvent(event.id)}
                    onMouseLeave={() => setActiveEvent(null)}
                  />
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <div className="rounded-full bg-muted p-3 mb-4">
                  <Search className="h-6 w-6 text-muted-foreground" />
                </div>
                <p className="text-lg font-medium">No events found</p>
                <p className="text-muted-foreground">Try adjusting your search criteria</p>
              </div>
            )}
          </TabsContent>
          <TabsContent value="calendar" className="animate-slide-up">
            <Card className="border-none shadow-lg">
              <CardHeader className="bg-gradient-to-r from-primary/10 to-secondary/10">
                <CardTitle>Event Calendar</CardTitle>
                <CardDescription>View all your events in calendar format</CardDescription>
              </CardHeader>
              <CardContent className="p-6">
                {isLoading ? (
                  <div className="flex items-center justify-center h-[400px]">
                    <div className="flex flex-col items-center gap-2">
                      <Loader2 className="h-8 w-8 text-primary animate-spin" />
                      <p className="text-sm text-muted-foreground">Loading calendar...</p>
                    </div>
                  </div>
                ) : (
                  <EventCalendar events={filteredEvents} />
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>

      <CreateEventModal isOpen={isCreateModalOpen} onClose={() => setIsCreateModalOpen(false)} />
    </div>
  )
}

function EventCard({ event, isActive, onMouseEnter, onMouseLeave }) {
  return (
    <Card
      className={cn("border-none shadow-md event-card", isActive && "ring-2 ring-primary/50")}
      onMouseEnter={onMouseEnter}
      onMouseLeave={onMouseLeave}
    >
      <CardHeader className="p-6">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-xl">{event.title}</CardTitle>
            <CardDescription className="mt-1">{event.description}</CardDescription>
          </div>
          <Badge className="bg-secondary hover:bg-secondary/90">{event.eventType || "Event"}</Badge>
        </div>
      </CardHeader>
      <CardContent className="px-6 pb-2">
        <div className="grid gap-3">
          <div className="flex items-center gap-2">
            <CalendarDays className="h-4 w-4 text-primary" />
            <span className="text-sm">{event.date}</span>
          </div>
          <div className="flex items-center gap-2">
            <Clock className="h-4 w-4 text-primary" />
            <span className="text-sm">{event.time}</span>
          </div>
          <div className="flex items-center gap-2">
            <MapPin className="h-4 w-4 text-primary" />
            <span className="text-sm">{event.location}</span>
          </div>
          <div className="flex items-center gap-2">
            <Users className="h-4 w-4 text-primary" />
            <span className="text-sm">{event.attendees} attendees</span>
          </div>
        </div>
      </CardContent>
      <CardFooter className="px-6 pb-6 pt-2">
        <Button asChild className="w-full bg-black text-white hover:bg-black/90 transition-opacity">
          <Link href={`/events/${event.id}`}>View Details</Link>
        </Button>
      </CardFooter>
    </Card>
  )
}

// Sample data with real Irish venues
const upcomingEvents = [
  {
    id: 1,
    title: "Dublin Tech Conference",
    description: "Ireland's biggest tech event of the year",
    date: "March 20, 2025",
    time: "9:00 AM - 5:00 PM",
    location: "Convention Centre Dublin",
    attendees: 120,
    coordinates: { lat: 53.34774, lng: -6.24059 },
    eventType: "Conference",
    image: "/placeholder.svg?height=200&width=400&text=Dublin+Tech+Conference",
  },
  {
    id: 2,
    title: "Cork Music Festival",
    description: "A celebration of Irish music and culture",
    date: "March 25, 2025",
    time: "2:00 PM - 10:00 PM",
    location: "Cork Opera House",
    attendees: 75,
    coordinates: { lat: 51.89997, lng: -8.47061 },
    eventType: "Festival",
    image: "/placeholder.svg?height=200&width=400&text=Cork+Music+Festival",
  },
  {
    id: 3,
    title: "Galway Food Festival",
    description: "Taste the best of Irish cuisine",
    date: "April 2, 2025",
    time: "12:00 PM - 8:00 PM",
    location: "Eyre Square, Galway",
    attendees: 45,
    coordinates: { lat: 53.27467, lng: -9.04886 },
    eventType: "Festival",
    image: "/placeholder.svg?height=200&width=400&text=Galway+Food+Festival",
  },
  {
    id: 4,
    title: "Belfast Business Summit",
    description: "Networking event for entrepreneurs",
    date: "April 10, 2025",
    time: "10:00 AM - 4:00 PM",
    location: "Titanic Belfast",
    attendees: 22,
    coordinates: { lat: 54.60856, lng: -5.90982 },
    eventType: "Business",
    image: "/placeholder.svg?height=200&width=400&text=Belfast+Business+Summit",
  },
  {
    id: 5,
    title: "Limerick Literary Festival",
    description: "Celebrating Irish literature and poetry",
    date: "April 15, 2025",
    time: "6:00 PM - 9:00 PM",
    location: "University of Limerick",
    attendees: 80,
    coordinates: { lat: 52.67397, lng: -8.57082 },
    eventType: "Cultural",
    image: "/placeholder.svg?height=200&width=400&text=Limerick+Literary+Festival",
  },
]

const allEvents = [
  ...upcomingEvents,
  {
    id: 6,
    title: "Kilkenny Craft Beer Festival",
    description: "Sample the finest craft beers from around Ireland",
    date: "April 22, 2025",
    time: "3:00 PM - 10:00 PM",
    location: "Kilkenny Castle",
    attendees: 35,
    coordinates: { lat: 52.65058, lng: -7.24957 },
    eventType: "Festival",
    image: "/placeholder.svg?height=200&width=400&text=Kilkenny+Craft+Beer+Festival",
  },
]

